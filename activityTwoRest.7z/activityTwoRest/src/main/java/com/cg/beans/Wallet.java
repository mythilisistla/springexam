package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Wallet_activity")
@Component
public class Wallet {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="walletactivityrestseq",initialValue=100,allocationSize=1)
	@Column(length=10)
	int walletId;
	double balance;
	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getWalletId() {
		return walletId;
	}
	public void setWalletId(int walletId) {
		this.walletId = walletId;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Wallet [walletId=" + walletId + ", balance=" + balance + "]";
	}
	
}
